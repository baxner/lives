import pygame
import random
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from config import *

class SoundManager:
    def __init__(self):
        try:
            pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
            self.enabled = True
        except:
            print("Warning: Audio system could not be initialized")
            self.enabled = False
            return

        self.sounds = {}
        self.generate_sounds()

    def generate_sounds(self):
        if not self.enabled: return
        
        # Helper to generate wave
        def make_sound(frequency, duration, wave_type="sine", volume=0.5):
            sample_rate = 44100
            n_samples = int(sample_rate * duration)
            t = np.linspace(0, duration, n_samples, False)
            
            if wave_type == "sine":
                wave = np.sin(2 * np.pi * frequency * t)
            elif wave_type == "square":
                wave = np.sign(np.sin(2 * np.pi * frequency * t))
            elif wave_type == "sawtooth":
                wave = 2 * (t * frequency - np.floor(t * frequency + 0.5))
            elif wave_type == "noise":
                wave = np.random.uniform(-1, 1, n_samples)
            else:
                wave = np.sin(2 * np.pi * frequency * t)
            
            # Fade out
            envelope = np.linspace(1, 0, n_samples)
            wave = wave * envelope * volume
            
            # Stereo (duplicate mono)
            stereo = np.column_stack((wave, wave))
            
            # Convert to 16-bit signed integers
            audio = (stereo * 32767).astype(np.int16)
            return pygame.sndarray.make_sound(audio)

        # 1. Pop (Spawn)
        self.sounds["pop"] = make_sound(600, 0.05, "sine", 0.3)
        
        # 2. Join (Ding)
        self.sounds["join"] = make_sound(880, 0.1, "sine", 0.4)
        
        # 3. Gift (Chime - Chord)
        # Create a major chord
        try:
           root = make_sound(523.25, 0.3, "sine", 0.4) # C5
           third = make_sound(659.25, 0.3, "sine", 0.4) # E5
           fifth = make_sound(783.99, 0.3, "sine", 0.4) # G5
           
           # Mix manually? No, just play sequentially or cache mixed?
           # For simplicity, just use the root "ding"
           self.sounds["gift"] = root
        except:
           pass

        # 4. Victory (Fanfare)
        self.sounds["win"] = make_sound(440, 0.5, "square", 0.5)
        
        # 5. Like (Tick - very short noise)
        self.sounds["tick"] = make_sound(0, 0.01, "noise", 0.1)

    def play(self, name):
        if self.enabled and name in self.sounds:
            try:
                self.sounds[name].play()
            except:
                pass

class Soldier:
    def __init__(self, team, username, power_level, images):
        self.team = team
        self.username = username
        self.images = images # Diccionario de imágenes {1: img1, 2: img2, 3: img3}
        self.tier = 1
        self.is_mini = False  # Para mini soldados de likes
        
        # Efectos visuales - MOVED UP before update_stats
        self.floating_texts = [] # Lista de (texto, x, y, timer)

        # Inicializar
        self.power_level = power_level  # Store current power
        self.update_stats(power_level)
        
        self.rect = self.image.get_rect()
        
        # Posición inicial aleatoria en Y
        self.rect.y = random.randint(SPAWN_Y_RANGE[0], SPAWN_Y_RANGE[1] - self.size)
        
        if self.team == "RED":
            self.rect.x = -self.size 
            self.direction = 1
        else:
            self.rect.x = WIDTH 
            self.direction = -1

    def update_stats(self, power_level):
        # Store updated power level
        self.power_level = power_level
        
        # Calcular Tier
        old_tier = self.tier
        if power_level >= TIER_4_THRESHOLD:
            self.tier = 4
        elif power_level >= TIER_3_THRESHOLD:
            self.tier = 3
        elif power_level >= TIER_2_THRESHOLD:
            self.tier = 2
        else:
            self.tier = 1
            
        # Si evolucionó, añadir efecto visual (placeholder)
        if self.tier > old_tier:
            self.add_floating_text("EVOLUTION!", (255, 255, 0))

        # Calcular tamaño
        self.size = BASE_SIZE + (power_level * GROWTH_FACTOR)
        self.size = min(self.size, MAX_SIZE)
        
        # Actualizar imagen según Tier
        self.original_image = self.images.get(self.tier, self.images[1])
        self.image = pygame.transform.scale(self.original_image, (self.size, self.size))
        
        # Voltear si es necesario (Asumimos sprites mirando a derecha por defecto)
        if self.team == "RED":
             if self.tier == 1:
                 pass # User feedback: Don't flip Tier 1 (or it was already flipped and needs unflip)
             else:
                 self.image = pygame.transform.flip(self.image, True, False)
        
        # Actualizar rect manteniendo el centro o posición
        if hasattr(self, 'rect'):
            center = self.rect.center
            self.rect = self.image.get_rect()
            self.rect.center = center
        
        self.health = self.size * 2 # Más vida

    def grow(self, points):
        self.add_floating_text(f"+{points}", (0, 255, 0))
        # La lógica de stats se maneja en el GameState llamando a update_stats con el nuevo total

    def add_floating_text(self, text, color):
        if not hasattr(self, 'rect'): return # Safety check
        self.floating_texts.append([text, self.rect.centerx, self.rect.top, 60, color]) # 60 frames de vida

    def move(self):
        self.rect.x += SPEED * self.direction

    def draw(self, screen, font, game_state=None):
        # Dibujar Imagen
        screen.blit(self.image, self.rect)
        
        # Mini soldados no muestran nombre ni puntos
        if self.is_mini:
            return
        
        # Renderizar Nombre CON EMOJIS
        try:
            display_name = self.username
            # Limitar longitud
            if len(display_name) > 15:
                display_name = display_name[:13] + ".."
            
            if game_state and hasattr(game_state, 'render_text_with_emoji'):
                # Usar PIL con caché para emojis
                text_surf = game_state.render_text_with_emoji(display_name, size=14, color=TEXT_COLOR)
            else:
                text_surf = font.render(display_name, True, TEXT_COLOR)
            
            if text_surf.get_width() > 0:
                text_x = self.rect.centerx - text_surf.get_width() // 2
                screen.blit(text_surf, (text_x, self.rect.top - 25))
        except:
            pass
        
        # Renderizar Puntos Acumulados (discreto, abajo del soldado)
        small_font = pygame.font.SysFont("Arial", 12, bold=False)
        
        # Determinar siguiente threshold
        if self.tier == 1:
            next_threshold = TIER_2_THRESHOLD
            progress_text = f"{self.power_level}/{next_threshold}"
        elif self.tier == 2:
            next_threshold = TIER_3_THRESHOLD
            progress_text = f"{self.power_level}/{next_threshold}"
        elif self.tier == 3:
            next_threshold = TIER_4_THRESHOLD
            progress_text = f"{self.power_level}/{next_threshold}"
        else:
            progress_text = f"{self.power_level} MAX"
        
        power_surf = small_font.render(progress_text, True, (200, 200, 200))
        power_x = self.rect.centerx - power_surf.get_width() // 2
        screen.blit(power_surf, (power_x, self.rect.bottom + 2))
        
        # Renderizar Textos Flotantes
        for ft in self.floating_texts[:]:
            text, x, y, timer, color = ft
            ft_surf = font.render(str(text), True, color)
            screen.blit(ft_surf, (x - ft_surf.get_width()//2, y))
            
            # Actualizar
            ft[2] -= 1 # Subir
            ft[3] -= 1 # Bajar timer
            if ft[3] <= 0:
                self.floating_texts.remove(ft)

class GameState:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Guerra de Tacos: ROJO vs AZUL")
        
        # Audio System
        self.sound_manager = SoundManager()
        
        # Usar fuentes con soporte Unicode/Emoji
        # Segoe UI tiene mejor soporte que Arial para caracteres internacionales
        try:
            self.font = pygame.font.SysFont("Segoe UI, Arial, sans-serif", 20, bold=True)
            self.ui_font = pygame.font.SysFont("Segoe UI, Arial, sans-serif", 40, bold=True)
        except:
            # Fallback a Arial si Segoe UI no está disponible
            self.font = pygame.font.SysFont("Arial", 20, bold=True)
            self.ui_font = pygame.font.SysFont("Arial", 40, bold=True)
        
        self.clock = pygame.time.Clock()
        
        self.red_army = [] # Lista de objetos Soldier
        self.blue_army = []
        
        self.game_over = False 
        
        self.user_power = {} # {username: puntos_totales}
        self.soldiers_map = {} # {(username, team): SoldierObject} <--- UPDATED KEY

        # Cargar Assets (Tier 1, 2, 3)
        self.assets = {
            "RED": {},
            "BLUE": {}
        }
        
        def load_img(path, color):
            try:
                img = pygame.image.load(path).convert_alpha()
                # img.set_colorkey((255, 255, 255)) # No longer needed with convert_alpha
                return img
            except:
                s = pygame.Surface((50, 50))
                s.fill(color)
                return s

        self.assets["RED"][1] = load_img("assets/red_soldier.png", RED_TEAM_COLOR)
        self.assets["RED"][2] = load_img("assets/red_soldier_t2.png", RED_TEAM_COLOR)
        self.assets["RED"][3] = load_img("assets/red_soldier_t3.png", RED_TEAM_COLOR)
        self.assets["RED"][4] = load_img("assets/red_soldier_t4.png", RED_TEAM_COLOR)  # Tier 4
        
        self.assets["BLUE"][1] = load_img("assets/blue_soldier.png", BLUE_TEAM_COLOR)
        self.assets["BLUE"][2] = load_img("assets/blue_soldier_t2.png", BLUE_TEAM_COLOR)
        self.assets["BLUE"][3] = load_img("assets/blue_soldier_t3.png", BLUE_TEAM_COLOR)
        self.assets["BLUE"][4] = load_img("assets/blue_soldier_t4.png", BLUE_TEAM_COLOR)  # Tier 4

        # Cargar Iconos de Regalos (con fallback para íconos faltantes)
        self.gift_icons = {}
        for gift_name in GIFT_MAP:
            # Nombre de archivo esperado: gift_rose.png, gift_taco.png, etc.
            safe_name = gift_name.lower().replace(" ", "_").replace("'", "").replace("-", "_")
            icon_path = f"assets/gift_{safe_name}.png"
            
            try:
                icon = pygame.image.load(icon_path).convert_alpha()
                self.gift_icons[gift_name] = icon
            except:
                # Crear ícono placeholder si falta el archivo
                placeholder = pygame.Surface((50, 50), pygame.SRCALPHA)
                placeholder.fill((100, 100, 100, 200))  # Gris semi-transparente
                # Añadir texto con iniciales
                initials = ''.join([word[0] for word in gift_name.split()[:2]])
                text_font = pygame.font.SysFont("Arial", 24, bold=True)
                text = text_font.render(initials, True, (255, 255, 255))
                text_rect = text.get_rect(center=(25, 25))
                placeholder.blit(text, text_rect)
                self.gift_icons[gift_name] = placeholder
                print(f"⚠️ Ícono no encontrado: {icon_path}, usando placeholder")

        # Cargar Textura de Nebulosa
        try:
            self.nebula_texture = pygame.image.load("assets/nebula_noise.png").convert_alpha()
        except:
            print("Warning: nebula_noise.png not found, using generic bg")
            self.nebula_texture = None

        # Victory System
        self.red_victories = 0
        self.blue_victories = 0
        self.victory_timer = 0  # Frames at 100% (300 frames = 5 seconds at 60 FPS)
        self.dominating_team = None  # "RED" or "BLUE" when at 100%

        # Join Team Assignment (alternating)
        self.next_join_team = "RED"  # Alterna entre RED y BLUE

        # Sistema de Likes - Períodos alternados de 10 segundos
        self.like_period_team = "RED"  # Equipo que recibe likes actualmente
        self.like_period_timer = 0     # Contador de frames (600 = 10 segundos)
        self.LIKE_PERIOD_DURATION = 600  # 10 segundos a 60 FPS

        # Sistema de Log Visual (mensajes flotantes)
        self.activity_log = []  # Lista de (mensaje, color, timer)
        self.LOG_MAX_ENTRIES = 8  # Máximo de mensajes visibles
        self.LOG_FADE_TIME = 300  # 5 segundos antes de desaparecer (60 FPS)

    def add_log(self, message, color=(255, 255, 255)):
        """Añade un mensaje al log visual"""
        self.activity_log.insert(0, {"msg": message, "color": color, "timer": self.LOG_FADE_TIME})
        # Limitar cantidad
        if len(self.activity_log) > self.LOG_MAX_ENTRIES:
            self.activity_log = self.activity_log[:self.LOG_MAX_ENTRIES]

    # Sistema de Caché de Texto con Emojis
    _text_cache = {}
    _emoji_font = None
    
    def render_text_with_emoji(self, text, size=14, color=(255, 255, 255)):
        """Renderiza texto con soporte de emojis usando PIL y caché"""
        # Limitar longitud para evitar problemas
        if len(text) > 30:
            text = text[:28] + ".."
        
        # Generar key de caché
        cache_key = (text, size, color)
        if cache_key in GameState._text_cache:
            return GameState._text_cache[cache_key]
        
        try:
            # Cargar fuente con soporte emoji (Windows)
            if GameState._emoji_font is None or GameState._emoji_font.size != size:
                try:
                    GameState._emoji_font = ImageFont.truetype("seguiemj.ttf", size)
                except:
                    try:
                        GameState._emoji_font = ImageFont.truetype("arial.ttf", size)
                    except:
                        GameState._emoji_font = ImageFont.load_default()
            
            font = GameState._emoji_font
            
            # Medir texto
            dummy_img = Image.new('RGBA', (1, 1))
            draw = ImageDraw.Draw(dummy_img)
            bbox = draw.textbbox((0, 0), text, font=font)
            text_width = max(bbox[2] - bbox[0], 1)
            text_height = max(bbox[3] - bbox[1], 1)
            
            # Crear imagen con padding
            img = Image.new('RGBA', (text_width + 4, text_height + 4), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)
            
            # Dibujar sombra
            draw.text((2, 2), text, font=font, fill=(0, 0, 0, 200))
            # Dibujar texto
            draw.text((1, 1), text, font=font, fill=color + (255,))
            
            # Convertir a Pygame Surface
            mode = img.mode
            size_tuple = img.size
            data = img.tobytes()
            pygame_surface = pygame.image.fromstring(data, size_tuple, mode)
            
            # Cachear (limitar tamaño de caché)
            if len(GameState._text_cache) > 500:
                # Limpiar mitad del caché
                keys = list(GameState._text_cache.keys())[:250]
                for k in keys:
                    del GameState._text_cache[k]
            
            GameState._text_cache[cache_key] = pygame_surface
            return pygame_surface
            
        except Exception as e:
            # Fallback a pygame normal sin emojis
            fallback = self.font.render(text[:20], True, color)
            return fallback

    def spawn_soldier(self, team, username, points):
        if team == "RESET":
            # Galaxy reset: clear EVERYTHING including victories
            self.reset_game(full_reset=True)
            return

        # Actualizar poder (Global accumulation or per team? Let's keep it simple: global accumulation for tiered growth)
        # But wait, if they switch teams, do they keep the size? 
        # For simplify, let's track points per user total for evolution, but soldier instances are separate.
        if username not in self.user_power:
            self.user_power[username] = 0
        self.user_power[username] += points
        
        current_power = self.user_power[username]
        
        # Verificar si ya existe el soldado EN ESE EQUIPO
        soldier_key = (username, team) # Tuple key
        
        if soldier_key in self.soldiers_map:
            soldier = self.soldiers_map[soldier_key]
            # Si el soldado murió (ya no está en los ejércitos)
            if soldier in self.red_army or soldier in self.blue_army:
                soldier.grow(points)
                soldier.update_stats(current_power)
            else:
                # Revivir
                self.create_new_soldier(team, username, current_power)
        else:
            # Nuevo soldado
            self.create_new_soldier(team, username, current_power)

    def create_new_soldier(self, team, username, power):
        self.sound_manager.play("pop")
        images = self.assets[team]
        new_soldier = Soldier(team, username, power, images)
        
        if team == "RED":
            self.red_army.append(new_soldier)
        else:
            self.blue_army.append(new_soldier)
            
        self.soldiers_map[(username, team)] = new_soldier

    def spawn_mini_soldier(self, team):
        """Spawn a mini soldier from a like (no username, half size)"""
        images = self.assets[team]
        # Crear mini soldado (1 power, sin nombre)
        mini = Soldier(team, "", 1, images)  # Power 1 (entero, no float)
        mini.is_mini = True  # Marcar como mini soldado
        # Hacer más pequeño (mitad de tamaño base)
        mini.size = int(BASE_SIZE // 2)
        mini.image = pygame.transform.scale(mini.images[1], (mini.size, mini.size))
        mini.rect = mini.image.get_rect()
        mini.rect.y = random.randint(SPAWN_Y_RANGE[0], SPAWN_Y_RANGE[1] - mini.size)
        mini.health = 50  # Más salud para que sobrevivan más
        
        if team == "RED":
            mini.rect.x = -mini.size
            mini.direction = 1
            self.red_army.append(mini)
        else:
            mini.rect.x = WIDTH
            mini.direction = -1
            self.blue_army.append(mini)

    def spawn_like_soldier(self):
        """Called when a like is received - spawns mini for current period team"""
        self.spawn_mini_soldier(self.like_period_team)

    def get_next_join_team(self):
        """Retorna el siguiente equipo para asignar y alterna"""
        team = self.next_join_team
        # Alternar para el próximo
        self.next_join_team = "BLUE" if self.next_join_team == "RED" else "RED"
        return team

    def update(self):
        # 0. Actualizar período de likes (cada 5 segundos alterna)
        self.like_period_timer += 1
        if self.like_period_timer >= self.LIKE_PERIOD_DURATION:
            self.like_period_timer = 0
            # Alternar equipo
            self.like_period_team = "BLUE" if self.like_period_team == "RED" else "RED"
            print(f"🔄 Likes ahora van para: {self.like_period_team}")

        # 1. Movimiento
        for s in self.red_army: s.move()
        for s in self.blue_army: s.move()

        # 2. Colisiones
        for red in self.red_army[:]:
            for blue in self.blue_army[:]:
                if red.rect.colliderect(blue.rect):
                    # Daño escalado por poder: Más puntos = Más daño
                    red_damage = 5 + (int(red.power_level) // 50)  # Daño base + bonus
                    blue_damage = 5 + (int(blue.power_level) // 50)
                    
                    red.health -= blue_damage  # Red recibe daño de Blue
                    blue.health -= red_damage  # Blue recibe daño de Red
                    
                    red.rect.x -= 2
                    blue.rect.x += 2

                    if red.health <= 0 and red in self.red_army:
                        self.red_army.remove(red)
                    if blue.health <= 0 and blue in self.blue_army:
                        self.blue_army.remove(blue)
                    break 

        # 3. Condición de Victoria (Modo Infinito: Solo empujan, no ganan instantáneo)
        for red in self.red_army[:]:
            if red.rect.x > WIDTH:
                red.rect.x = -red.size # Vuelve a empezar (Loop infinito)
                
        for blue in self.blue_army[:]:
            if blue.rect.x < -blue.size:
                blue.rect.x = WIDTH # Vuelve a empezar

        # 4. Victory Detection System
        # Calculate team percentages
        total_red = sum([s.size for s in self.red_army]) + 1
        total_blue = sum([s.size for s in self.blue_army]) + 1
        total = total_red + total_blue
        pct_red = total_red / total
        pct_blue = total_blue / total

        # Check for 94% dominance
        if pct_red >= 0.94:  # 94% Red (with small tolerance)
            if self.dominating_team == "RED":
                self.victory_timer += 1
            else:
                self.dominating_team = "RED"
                self.victory_timer = 0
        elif pct_blue >= 0.94:  # 94% Blue
            if self.dominating_team == "BLUE":
                self.victory_timer += 1
            else:
                self.dominating_team = "BLUE"
                self.victory_timer = 0
        else:
            # No dominance, reset timer
            self.dominating_team = None
            self.victory_timer = 0

        # Victory condition (5 seconds = 300 frames at 60 FPS)
        if self.victory_timer >= 300:
            self.handle_victory(self.dominating_team)

        # Actualizar timers del activity log
        for log_entry in self.activity_log[:]:
            log_entry["timer"] -= 1
            if log_entry["timer"] <= 0:
                self.activity_log.remove(log_entry)

    def draw_activity_log(self):
        """Dibuja el log de actividad arriba del panel de leyenda"""
        y_offset = HEIGHT - 140  # Justo arriba del panel de 120px
        
        for i, entry in enumerate(self.activity_log):
            # Calcular alpha basado en timer restante
            alpha = min(255, int(255 * (entry["timer"] / self.LOG_FADE_TIME)))
            if alpha <= 0:
                continue
            
            # Renderizar texto CON EMOJIS usando PIL
            text = self.render_text_with_emoji(entry["msg"], size=14, color=entry["color"])
            text.set_alpha(alpha)
            
            # Posición (izquierda)
            y_pos = y_offset - (i * 18)
            self.screen.blit(text, (10, y_pos))

    def draw_legend(self):
        # Panel semitransparente MÁS GRANDE para más espacio
        panel_height = 120  # Aumentado de 80 a 120
        s = pygame.Surface((WIDTH, panel_height))
        s.set_alpha(180)
        s.fill((0, 0, 0))
        self.screen.blit(s, (0, HEIGHT - panel_height))

        # Dividir regalos en dos filas para ahorrar espacio
        # Fila 1: Red (Izq) y Blue (Der) basicos
        # Fila 2: Especiales o caros
        
        # Configuración compacta: Icono (30x30) + Texto pequeño
        small_font = pygame.font.SysFont("Arial", 14, bold=True)
        
        # Render helper
        def draw_gift_item(x, y, name, color):
             icon = self.gift_icons.get(name)
             if icon:  # Check if icon exists
                 icon = pygame.transform.scale(icon, (30, 30))
                 self.screen.blit(icon, (x, y))
             # Solo mostrar primera letra o corto si es muy largo? No, solo nombre
             # Hack: Si es muy largo, cortar
             display_name = name[:8] + ".." if len(name) > 10 else name
             text = small_font.render(f"{display_name}", True, color)
             self.screen.blit(text, (x + 35, y + 8))

        # Gifts Layout - 3 FILAS para más espacio
        # Red Side (Left)
        # Fila 1 - Básicos
        draw_gift_item(10, HEIGHT - 115, "Rose", RED_TEAM_COLOR)           # Básico (1)
        draw_gift_item(10, HEIGHT - 80, "Heart Me", RED_TEAM_COLOR)        # Básico (1)
        # Fila 2 - Medios
        draw_gift_item(10, HEIGHT - 45, "Hand Hearts", RED_TEAM_COLOR)     # Medio (100)
        draw_gift_item(120, HEIGHT - 115, "Pawfect", RED_TEAM_COLOR)       # Caro (299)
        # Fila 3 - Caros
        draw_gift_item(120, HEIGHT - 80, "Money Gun", RED_TEAM_COLOR)      # Ultra (500)
        draw_gift_item(120, HEIGHT - 45, "Love U", RED_TEAM_COLOR)         # Ultra (899)

        # Blue Side (Right)
        # Fila 1 - Básicos  
        draw_gift_item(WIDTH - 100, HEIGHT - 115, "GG", BLUE_TEAM_COLOR)        # Básico (1)
        draw_gift_item(WIDTH - 100, HEIGHT - 80, "I'm Ready", BLUE_TEAM_COLOR)  # Básico (1)
        # Fila 2 - Medios
        draw_gift_item(WIDTH - 100, HEIGHT - 45, "Super GG", BLUE_TEAM_COLOR)   # Medio (100)
        draw_gift_item(WIDTH - 220, HEIGHT - 115, "Corgi", BLUE_TEAM_COLOR)     # Caro (299)
        # Fila 3 - Caros
        draw_gift_item(WIDTH - 220, HEIGHT - 80, "Train", BLUE_TEAM_COLOR)      # Ultra (899)
        draw_gift_item(WIDTH - 220, HEIGHT - 45, "Gem Gun", BLUE_TEAM_COLOR)    # Ultra (500)
        
        # Special (Center) - Galaxy RESET - centrado y visible
        galaxy_x = WIDTH // 2 - 50
        draw_gift_item(galaxy_x, HEIGHT - 85, "Galaxy", (255, 0, 255))
        # Add "RESET" text below Galaxy
        reset_label = small_font.render("RESET", True, (255, 100, 255))
        self.screen.blit(reset_label, (galaxy_x + 35, HEIGHT - 50))

    def draw_dynamic_background(self, pct_red):
        # Draw background with smooth gradient based on percentage
        split_x = int(WIDTH * pct_red)
        
        # Create smooth horizontal gradient
        for x in range(WIDTH):
            # Calculate color based on position
            ratio = x / WIDTH
            
            # Smooth transition between red and blue
            if ratio < pct_red:
                # Red territory - gradient from dark to bright red
                intensity = 0.3 + (ratio / pct_red) * 0.4 if pct_red > 0 else 0.7
                r = int(180 * intensity)
                g = int(30 * intensity)
                b = int(30 * intensity)
            else:
                # Blue territory - gradient from dark to bright blue
                intensity = 0.3 + ((ratio - pct_red) / (1 - pct_red)) * 0.4 if pct_red < 1 else 0.7
                r = int(30 * intensity)
                g = int(30 * intensity)
                b = int(180 * intensity)
            
            # Draw vertical line with this color
            pygame.draw.line(self.screen, (r, g, b), (x, 0), (x, HEIGHT))
        
        # Add radial glow effects from edges
        glow_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        
        # Red glow from left if RED is winning
        if pct_red > 0.3:
            for i in range(5):
                alpha = int(30 * pct_red * (5 - i) / 5)
                glow_width = int(WIDTH * 0.2 * (i + 1))
                pygame.draw.rect(glow_surface, (255, 50, 50, alpha), 
                               (0, 0, glow_width, HEIGHT))
        
        # Blue glow from right if BLUE is winning
        if pct_red < 0.7:
            for i in range(5):
                alpha = int(30 * (1 - pct_red) * (5 - i) / 5)
                glow_width = int(WIDTH * 0.2 * (i + 1))
                pygame.draw.rect(glow_surface, (50, 50, 255, alpha),
                               (WIDTH - glow_width, 0, glow_width, HEIGHT))
        
        self.screen.blit(glow_surface, (0, 0))
        
        # Draw Noise Texture overlay (subtle)
        if self.nebula_texture:
            texture_copy = self.nebula_texture.copy()
            texture_copy.set_alpha(80)  # More subtle
            self.screen.blit(texture_copy, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)

    def draw(self):
        # Calculate percentages first for background
        total_red = sum([s.size for s in self.red_army]) + 1
        total_blue = sum([s.size for s in self.blue_army]) + 1
        total = total_red + total_blue
        pct_red = total_red / total
        
        # 1. Background Dinámico
        self.draw_dynamic_background(pct_red)

        for s in self.red_army: s.draw(self.screen, self.font, self)
        for s in self.blue_army: s.draw(self.screen, self.font, self)

        # UI Minimalista (Texto en esquinas)
        # Sombra negra para legibilidad
        
        def draw_text_with_shadow(text, x, y, color):
            shadow = self.ui_font.render(text, True, (0, 0, 0))
            surf = self.ui_font.render(text, True, color)
            self.screen.blit(shadow, (x+2, y+2))
            self.screen.blit(surf, (x, y))

        # Usar fuente más pequeña para UI compacta
        compact_font = pygame.font.SysFont("Arial", 28, bold=True)
        
        red_surf = compact_font.render(f"ROJO {int(pct_red*100)}%", True, (255, 200, 200))
        blue_surf = compact_font.render(f"{int((1-pct_red)*100)}% AZUL", True, (200, 200, 255))
        
        # Shadow manually for compact font
        self.screen.blit(compact_font.render(f"ROJO {int(pct_red*100)}%", True, (0,0,0)), (12, 12))
        self.screen.blit(red_surf, (10, 10))
        
        self.screen.blit(compact_font.render(f"{int((1-pct_red)*100)}% SUADERO", True, (0,0,0)), (WIDTH - blue_surf.get_width() - 8, 12))
        self.screen.blit(blue_surf, (WIDTH - blue_surf.get_width() - 10, 10))
        
        # Victory Scoreboard (Central)
        score_font = pygame.font.SysFont("Arial", 56, bold=True)
        red_score_surf = score_font.render(f"{self.red_victories}", True, (255, 100, 100))
        blue_score_surf = score_font.render(f"{self.blue_victories}", True, (100, 100, 255))
        dash_surf = score_font.render("-", True, (200, 200, 200))
        
        # Shadow for scoreboard
        self.screen.blit(score_font.render(f"{self.red_victories}", True, (0,0,0)), (WIDTH//2 - 72, 52))
        self.screen.blit(red_score_surf, (WIDTH//2 - 70, 50))
        
        self.screen.blit(score_font.render("-", True, (0,0,0)), (WIDTH//2 - 17, 52))
        self.screen.blit(dash_surf, (WIDTH//2 - 15, 50))
        
        self.screen.blit(score_font.render(f"{self.blue_victories}", True, (0,0,0)), (WIDTH//2 + 32, 52))
        self.screen.blit(blue_score_surf, (WIDTH//2 + 30, 50))
        
        # Like Period Indicator (debajo del marcador) CON EMOJI
        like_seconds_left = (self.LIKE_PERIOD_DURATION - self.like_period_timer) // 60
        like_team_color = (255, 100, 100) if self.like_period_team == "RED" else (100, 100, 255)
        like_team_name = "ROJO" if self.like_period_team == "RED" else "AZUL"
        
        like_text = f"LIKES → {like_team_name} ({like_seconds_left}s)"
        like_surf = self.render_text_with_emoji(like_text, size=18, color=like_team_color)
        
        like_x = WIDTH // 2 - like_surf.get_width() // 2
        self.screen.blit(like_surf, (like_x, 110))
        
        # Countdown Timer (when dominating)
        if self.dominating_team:
            seconds_left = 5 - (self.victory_timer // 60)
            if seconds_left >= 0:  # Only show positive countdown
                timer_font = pygame.font.SysFont("Arial", 80, bold=True)
                timer_color = RED_TEAM_COLOR if self.dominating_team == "RED" else BLUE_TEAM_COLOR
                timer_text = timer_font.render(f"{seconds_left}", True, timer_color)
                
                # Pulsing effect based on timer
                pulse = int(abs((self.victory_timer % 30) - 15) * 1.5)
                offset = pulse
                
                # Draw with glow effect (multiple shadows)
                for i in range(3, 0, -1):
                    glow = timer_font.render(f"{seconds_left}", True, (timer_color[0]//2, timer_color[1]//2, timer_color[2]//2))
                    self.screen.blit(glow, (WIDTH//2 - timer_text.get_width()//2 - offset - i*2, 130 - offset - i*2))
                
                shadow = timer_font.render(f"{seconds_left}", True, (0, 0, 0))
                self.screen.blit(shadow, (WIDTH//2 - timer_text.get_width()//2 - offset + 3, 130 - offset + 3))
                self.screen.blit(timer_text, (WIDTH//2 - timer_text.get_width()//2 - offset, 130 - offset))
        
        # Old UI lines removed to prevent NameError and overlap

        # Activity Log (arriba del panel de leyenda)
        self.draw_activity_log()
        
        self.draw_legend()

        pygame.display.flip()

    def handle_victory(self, winning_team):
        """Handle victory condition: increment score and reset battlefield"""
        # Increment victory count
        if winning_team == "RED":
            self.red_victories += 1
            team_name = "ROJO"
            color = RED_TEAM_COLOR
            bg_color = (80, 20, 20)
            accent = (255, 100, 100)
        else:
            self.blue_victories += 1
            team_name = "AZUL"
            color = BLUE_TEAM_COLOR
            bg_color = (20, 20, 80)
            accent = (100, 100, 255)

        # ===== PANTALLA DE VICTORIA ÉPICA =====
        self.sound_manager.play("win")
        for frame in range(120):  # 2 segundos de animación
            # Fondo con gradiente pulsante
            pulse = abs(60 - frame) / 60.0
            r = int(bg_color[0] + (color[0] - bg_color[0]) * pulse * 0.5)
            g = int(bg_color[1] + (color[1] - bg_color[1]) * pulse * 0.5)
            b = int(bg_color[2] + (color[2] - bg_color[2]) * pulse * 0.5)
            self.screen.fill((r, g, b))
            
            # Rayos de luz desde el centro
            glow_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            for i in range(8):
                angle = (frame * 2 + i * 45) % 360
                import math
                end_x = WIDTH//2 + int(math.cos(math.radians(angle)) * 500)
                end_y = HEIGHT//2 + int(math.sin(math.radians(angle)) * 500)
                alpha = int(100 * pulse)
                pygame.draw.line(glow_surf, accent + (alpha,), (WIDTH//2, HEIGHT//2), (end_x, end_y), 3)
            self.screen.blit(glow_surf, (0, 0))
            
            # Círculo de glow central
            glow_radius = int(150 + 50 * pulse)
            glow_circle = pygame.Surface((glow_radius*2, glow_radius*2), pygame.SRCALPHA)
            for r_offset in range(glow_radius, 0, -10):
                alpha = int(50 * (r_offset / glow_radius) * pulse)
                pygame.draw.circle(glow_circle, accent + (alpha,), (glow_radius, glow_radius), r_offset)
            self.screen.blit(glow_circle, (WIDTH//2 - glow_radius, HEIGHT//2 - glow_radius - 50))
            
            # Texto principal - "ROJO GANA!" o "AZUL GANA!"
            victory_font = pygame.font.SysFont("Arial Black", 80, bold=True)
            main_text = f"{team_name} GANA!"
            
            # Sombra sólida simple (no múltiples capas)
            shadow = victory_font.render(main_text, True, (0, 0, 0))
            self.screen.blit(shadow, (WIDTH//2 - shadow.get_width()//2 + 4, HEIGHT//2 - 60 + 4))
            
            # Contorno negro (para mejor definición)
            for ox, oy in [(-2,0), (2,0), (0,-2), (0,2), (-2,-2), (2,2), (-2,2), (2,-2)]:
                outline = victory_font.render(main_text, True, (0, 0, 0))
                self.screen.blit(outline, (WIDTH//2 - outline.get_width()//2 + ox, HEIGHT//2 - 60 + oy))
            
            # Texto principal brillante
            victory_text = victory_font.render(main_text, True, color)
            self.screen.blit(victory_text, (WIDTH//2 - victory_text.get_width()//2, HEIGHT//2 - 60))
            
            # Subtítulo con score
            sub_font = pygame.font.SysFont("Arial", 36, bold=True)
            score_text = f"{self.red_victories} - {self.blue_victories}"
            score_surf = sub_font.render(score_text, True, (255, 255, 255))
            self.screen.blit(sub_font.render(score_text, True, (0,0,0)), (WIDTH//2 - score_surf.get_width()//2 + 2, HEIGHT//2 + 52))
            self.screen.blit(score_surf, (WIDTH//2 - score_surf.get_width()//2, HEIGHT//2 + 50))
            
            # Partículas/estrellas
            if frame % 5 == 0:
                for _ in range(5):
                    px = random.randint(0, WIDTH)
                    py = random.randint(0, HEIGHT)
                    pygame.draw.circle(self.screen, (255, 255, 255), (px, py), random.randint(1, 3))
            
            pygame.display.flip()
            pygame.time.delay(16)  # ~60 FPS

        # Reset battlefield (but not victory counts)
        self.reset_game()

    def reset_game(self, full_reset=False):
        # Clear battlefield (always)
        self.red_army.clear()
        self.blue_army.clear()
        self.user_power.clear()
        self.soldiers_map.clear()
        self.victory_timer = 0
        self.dominating_team = None
        
        # Galaxy reset: clear victories too
        if full_reset:
            self.red_victories = 0
            self.blue_victories = 0
        
        # Pantalla blanca flash
        self.screen.fill((255, 255, 255))
        pygame.display.flip()
        pygame.time.delay(500)

    def run_frame(self):
        self.update()
        self.draw()
        self.clock.tick(FPS)