# config.py

# --- CONFIGURACIÓN DE PANTALLA ---
WIDTH = 540
HEIGHT = 960
FPS = 60

# --- COLORES (R, G, B) ---
RED_TEAM_COLOR = (255, 80, 80)   # Color para equipo ROJO
BLUE_TEAM_COLOR = (80, 80, 255)  # Color para equipo AZUL
TEXT_COLOR = (255, 255, 255)
BAR_BG_COLOR = (50, 50, 50)
BG_COLOR = (30, 30, 30)          # Fondo gris oscuro

# --- JUGABILIDAD ---
BASE_SIZE = 60           # Tamaño inicial del soldado (en pixeles)
GROWTH_FACTOR = 10       # Cuánto crece el soldado por cada punto extra donado
MAX_SIZE = 300           # Tamaño máximo permitido
SPEED = 3                # Velocidad de movimiento
SPAWN_Y_RANGE = (150, 800) # Área vertical donde pueden aparecer

# --- MAPA DE REGALOS ---
# Formato: 'NombreDelRegalo': (Puntos, 'EQUIPO')
# Puntos = Valor en monedas de TikTok
# RED = Izquierda (ROJO), BLUE = Derecha (AZUL)
# *** EQUILIBRADO: Cada equipo tiene 2 básicos, 2 medios, 2 caros ***
GIFT_MAP = {
    # Regalos básicos (1 moneda) - 2 por equipo
    "Rose": (1, "RED"),
    "Heart Me": (1, "RED"),
    "GG": (1, "BLUE"),
    "I'm Ready": (1, "BLUE"),  # Bob Esponja
    
    # Regalos medios (100-199) - 2 por equipo
    "Hand Hearts": (100, "RED"),
    "Marvelous Confetti": (100, "RED"),
    "Super GG": (100, "BLUE"),
    "Confetti": (100, "BLUE"),
    
    # Regalos caros (299-899) - 2 por equipo
    "Pawfect": (299, "RED"),
    "Money Gun": (500, "RED"),
    "Gem Gun": (500, "BLUE"),
    "Corgi": (299, "BLUE"),
    "Train": (899, "BLUE"),
    "Love U": (899, "RED"),
    
    # Reset
    "Galaxy": (9999, "RESET")
}

# --- EVOLUCIÓN ---
# Ajustados para la economía real (valores monetarios reales)
TIER_2_THRESHOLD = 100   # ~100 monedas (Hand Hearts, Super GG, etc.)
TIER_3_THRESHOLD = 299   # ~300 monedas (Pawfect, Corgi)
TIER_4_THRESHOLD = 500   # ~500 monedas (Money Gun, Train)
TIER_5_THRESHOLD = 899  # ~1000 monedas (Galaxy)