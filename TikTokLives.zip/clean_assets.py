import os
from PIL import Image, ImageOps

ASSETS_DIR = "d:/TikTokLives/assets/"
THRESHOLD = 200  # Threshold for white background removal

def process_image(filename):
    path = os.path.join(ASSETS_DIR, filename)
    try:
        img = Image.open(path).convert("RGBA")
        
        # Create a mask using floodfill from top-left corner
        # This assumes the background at (0,0) is representative
        # We add a generous tolerance (fuzziness)
        
        # Convert to RGB for floodfill (alpha doesn't matter for finding bg)
        bg = Image.new("RGBA", img.size, (255, 255, 255, 0))
        
        # Calculate mask of background
        # We'll use ImageOps or manual floodfill logic with a tolerance
        # Since Pillow's floodfill is simple, let's try a robust approach:
        # 1. Convert to simple RGB
        # 2. Get difference from white (or top-left pixel)
        # 3. Threshold to binary
        # 4. Flood fill outer area
        
        # Simpler approach: Use Image.floodfill (available in newer Pillow or implement)
        # Or simpler: get corner color, make "difference" image, threshold, find connected component from corner
        
        # Let's stick to a per-pixel check but only for "outer" pixels? No that's hard.
        # Let's use the ImageDraw.floodfill if available or a simple DFS/BFS if image is small.
        # Gift icons are small (~100px).
        
        # Simplified robust approach for white BG:
        # Create a mask where white = 0, others = 255
        # No, that deletes internal white.
        
        # Let's use a BFS for flood fill from (0,0)
        width, height = img.size
        pixels = img.load()
        
        # Get background color sample from (0,0)
        bg_color = pixels[0, 0]
        
        # Setup BFS
        queue = [(0, 0), (width-1, 0), (0, height-1), (width-1, height-1)]
        visited = set(queue)
        
        # Helper to check color similarity
        def is_bg(p):
            r, g, b, a = p
            # Check if close to white (assuming white BG) or close to corner color
            return r > THRESHOLD and g > THRESHOLD and b > THRESHOLD
            
        while queue:
            x, y = queue.pop(0)
            if is_bg(pixels[x, y]):
                pixels[x, y] = (0, 0, 0, 0) # Make transparent
                
                # Neighbors
                for nx, ny in [(x+1, y), (x-1, y), (x, y+1), (x, y-1)]:
                    if 0 <= nx < width and 0 <= ny < height and (nx, ny) not in visited:
                        visited.add((nx, ny))
                        queue.append((nx, ny))
                        
        # Crop to content
        bbox = img.getbbox()
        if bbox:
            img = img.crop(bbox)
        
        img.save(path, "PNG")
        print(f"Processed (FloodFill): {filename}")
        
    except Exception as e:
        print(f"Error processing {filename}: {e}")

if __name__ == "__main__":
    print("Starting asset cleanup...")
    for filename in os.listdir(ASSETS_DIR):
        if filename.startswith("gift_") and filename.endswith(".png"):
            process_image(filename)
    print("Done.")
