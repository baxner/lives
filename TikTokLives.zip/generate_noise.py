from PIL import Image
import random
import os

def generate_noise_texture(width, height, output_path):
    img = Image.new('RGBA', (width, height))
    pixels = img.load()
    
    for y in range(height):
        for x in range(width):
            # Simple static noise
            v = random.randint(0, 100)
            # Alpha controls opacity of the noise
            pixels[x, y] = (255, 255, 255, random.randint(10, 30))
            
    img.save(output_path)
    print(f"Generated noise texture: {output_path}")

if __name__ == "__main__":
    # Generate a texture slightly larger than screen to allow for potential parallax later 
    # but for now just screen size (540x960)
    generate_noise_texture(540, 960, "d:/TikTokLives/assets/nebula_noise.png")
